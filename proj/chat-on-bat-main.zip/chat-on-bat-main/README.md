## chat-on-bat

Онлайн чат написаный на bat + js (модуль для работы с http)

## Подключения
<b>Если у вас нет вашего сервера: то пользуйтесь загрузчиком данных на хост. Подробнее про хост перейдите по этой ссылке:</b> https://github.com/arersen/arersendrive
#### add
#### username: ник по английски
#### filename: chat.txt
#### https://arersengit.7m.pl/files/example/chat.txt
